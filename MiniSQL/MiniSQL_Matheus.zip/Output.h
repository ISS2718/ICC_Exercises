#ifndef ___OUTPUT___
#define ___OUTPUT___

#include "Archive.h"
#include "Input.h"

typedef struct Output {
	Archive* Files;
	unsigned int Size;
	unsigned int FileNumber;
}Output;

void ConstructOutput(Output* O, const Input* I);
void DestroyOutput(Output* O);
unsigned int GetArchiveIndex(const Output* O, const String* ArchiveName);
Position ColumnCoordinates(const Output* O, const String* S);
int Condition(const Output* O, const String* S1, const String* S2);
int TotalCondition(const Output* O, const Input* I);
void NullifyWithConstant(Output* O, const Position Coordinates, const String* Constant);
void MakeConstantComparissons(Output* O, Input* I);
void PrintCurrentLine(const Output* O, const Input* I);
void PrintOutput(Output* O, const Input* I);

#endif