#include "Other.h"

void ConstructVector(Vector* V, const unsigned int size){
	V->Entries = (int*)calloc(size, sizeof(int));
	if (V->Entries == NULL) {
		printf("Error: Unable to allocate memory for Vector\n");
		exit(-1);
	}
	V->Size = size;
}

void DestroyVector(Vector* V){
	free(V->Entries);
}

void SetVectorEntry(Vector* V, const unsigned int Entry, const int Value){
	if (Entry >= V->Size) {
		printf("Error: Trying to set entry outside Vector bounds\n");
		exit(-1);
	}
	V->Entries[Entry] = Value;
}

Position Point(const unsigned int R, const unsigned int C){
	Position Result;
	Result.Row = R;
	Result.Column = C;
	return Result;
}

void CopyPosition(Position* Destiny, const Position Source){
	Destiny->Row = Source.Row;
	Destiny->Column = Source.Column;
}

unsigned int GetTextSize(const char* Text){
	unsigned int Size = 0;
	while (Text[Size] != '\0') {
		Size++;
	}
	return Size;
}

unsigned int GetBinaryDigit(unsigned int N, unsigned int Position) {
	const unsigned int Mask = 1;
	N >>= Position;
	N &= Mask;
	return N;
}
