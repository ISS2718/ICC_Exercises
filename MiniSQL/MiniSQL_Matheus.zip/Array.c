#include "Array.h"

void ConstructArrayFromString(Array* A, const String* S){
	A->Size = 1;
	A->Entries = (String*)calloc(A->Size, sizeof(String));
	if (A->Entries == NULL) {
		printf("Error: Failure to allocate memory for Array\n");
		exit(-1);
	}
	ConstructStringFromString(&(A->Entries[0]), S);
}

void ConstructArrayFromText(Array* A, const char* Text){
	A->Size = 1;
	A->Entries = (String*)calloc(A->Size, sizeof(String));
	if (A->Entries == NULL) {
		printf("Error: Failure to allocate memory for Array\n");
		exit(-1);
	}
	ConstructStringFromText(&(A->Entries[0]), Text);
}

void DestroyArray(Array* A){
	for (unsigned int i = 0; i < A->Size; i++) {
		DestroyString(&(A->Entries[i]));
	}
	free(A->Entries);
}

void PushStringIntoArray(Array* A, const String* S){
	if (A->Entries == NULL) {
		printf("Error: Can't push String into nonconstructed Array\n");
		exit(-1);
	}
	A->Size += 1;
	String* Temporary = (String*)realloc(A->Entries, (A->Size) * sizeof(String));
	if (Temporary == NULL) {
		printf("Error: Failure to allocate memory for Array expansion\n");
		exit(-1);
	}
	A->Entries = Temporary;
	ConstructStringFromString(&(A->Entries[A->Size - 1]), S);
}

void SetArrayEntry(Array* A, const String* S, unsigned int Entry){
	if (Entry >= A->Size) {
		printf("Error: Poor specification of Array index\n");
		exit(-1);
	}
	CopyString(&(A->Entries[Entry]), S);
}

void NullifyArrayEntry(Array* A, const unsigned int Entry){
	if (Entry >= A->Size) {
		printf("Error: Trying to nullify String outside Array bounds\n");
		exit(-1);
	}
	NullifyString(&(A->Entries[Entry]));
}

void PrintArray(const Array* A){
	for (unsigned int i = 0; i < A->Size; i++) {
		PrintString(&(A->Entries[i]));
		printf(" | ");
	}
}
