#include "String.h"
#include "Other.h"
#include "Array.h"
#include "Matrix.h"
#include "Input.h"
#include "Archive.h"
#include "Output.h"


int main(int Argument01, char** Argument02) {
	Input I;
	ConstructInput(&I);
	Output O;
	ConstructOutput(&O, &I);
	MakeConstantComparissons(&O, &I);
	PrintOutput(&O, &I);
	DestroyInput(&I);
	DestroyOutput(&O);
}