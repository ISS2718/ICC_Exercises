#ifndef ___ARRAY___
#define ___ARRAY___

#include<stdio.h>
#include<stdlib.h>
#include "Other.h"
#include "String.h"

typedef struct Array {
	String* Entries;
	unsigned int Size;
}Array;

void ConstructArrayFromString(Array* A, const String* S);
void ConstructArrayFromText(Array* A, const char* Text);
void DestroyArray(Array* A);
void PushStringIntoArray(Array* A, const String* S);
void SetArrayEntry(Array* A, const String* S, unsigned int Entry);
void NullifyArrayEntry(Array* A, const unsigned int Entry);
void PrintArray(const Array* A);

#endif