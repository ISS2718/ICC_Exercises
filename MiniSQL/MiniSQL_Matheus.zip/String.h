#ifndef ___STRING___
#define ___STRING___

#include<stdio.h>
#include<stdlib.h>
#include "Other.h"

typedef struct String {
	char* Content;
	unsigned int Size;
}String;

void ConstructStringOfLength(String* S, unsigned int Length);
void ConstructString(String* S);
void ConstructStringFromText(String* S, const char* Text);
void ConstructStringFromSubString(String* S, const String* Source, const unsigned int InitialIndex, const unsigned int FinalIndex);
void ConstructStringFromString(String* S, const String* Source);
void ConstructStringFromPreffix(String* S, const String* Source);
void ConstructStringFromSuffix(String* S, const String* Source);
void DestroyString(String* S);
void PushCharIntoString(String* S, const char Character);
void PushTextIntoString(String* S, const char* Text);
int CompareStrings(const String* S1, const String* S2);
int StringIsText(String* S, const char* Text);
int StringHaveChar(const String* S, const char Character);
void CopySubString(String* Destiny, const String* Source, const unsigned int InitialIndex, const unsigned int FinalIndex);
void CopyString(String* Destiny, const String* Source);
void SetStringToPreffix(String* Destiny, const String* Source);
void NullifyString(String* S);
void SetStringToSuffix(String* Destiny, const String* Source);
int MinStringSize(const String* S1, const String* S2);
int PreffixIsString(const String* PreffixOfThat, const String* IsThat);
int SuffixIsString(const String* SuffixOfThat, const String* IsThat);
void PassString(String* Destiny, String* Source);
void PrintString(const String* S);

#endif