#ifndef ___MATRIX___
#define ___MATRIX___

#include<stdio.h>
#include<stdlib.h>
#include "Other.h"
#include "String.h"
#include "Array.h"

typedef struct Matrix {
	String** Entries;
	Position Size;
}Matrix;

void ConstructMatrix(Matrix* M, const Position Dimensions);
void DestroyMatrix(Matrix* M);
void SetMatrixEntry(Matrix* M, const String* S, const Position Entry);
void NullifyMatrixEntry(Matrix* M, const Position Entry);
void NullifyMatrixRow(Matrix* M, const unsigned int Row);
void NullifyMatrixColumn(Matrix* M, const unsigned int Column);
void PassStringToMatrix(Matrix* M, String* Source, const Position Entry);
int CompareEntryToConstant(const Matrix* M, const String* Constant, const Position Entry);
int CompareEntryToColumn(const Matrix* EntryHere, const Position Entry, const Matrix* ColumnHere, unsigned int Column);
int CompareEntryToRow(const Matrix* EntryHere, const Position Entry, const Matrix* RowHere, unsigned int Row);
void PrintMatrix(const Matrix* M);
void PrintMatrixEntry(const Matrix* M, const Position Entry);

#endif