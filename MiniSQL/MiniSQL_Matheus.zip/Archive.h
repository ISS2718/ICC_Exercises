#ifndef ___ARCHIVE___
#define ___ARCHIVE___

#include "Matrix.h"

typedef struct Archive {
	String Name;
	Matrix Content;
	unsigned int Iterator;
	Vector NullRows;
}Archive;

void ConstructArchive(Archive* A, const String ArchiveName);
void DestroyArchive(Archive* A);
unsigned int ColumnNumber(Archive* A, const String Text);
void NullifyArchiveRow(Archive* A, unsigned int Row);
unsigned int GetColumnIndex(const Archive* A, const String* ColumnName);
void PrintArchive(const Archive* A);
void PrintArchiveEntry(const Archive* A, const Position Entry);

#endif