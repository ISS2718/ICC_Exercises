#include "Output.h"

void ConstructOutput(Output* O, const Input* I){
	O->Size = I->From.Size - 1;
	O->Files = (Archive*)calloc(O->Size, sizeof(Archive));
	if (O->Files == NULL) {
		printf("Error: Failure to allocate memory for Output\n");
		exit(-1);
	}
	for (unsigned int i = 1; i < I->From.Size; i++) {
		ConstructArchive(&(O->Files[i - 1]), I->From.Entries[i]);
	}
	O->FileNumber = O->Size - 1;
}

void DestroyOutput(Output* O){
	for (unsigned int i = 0; i < O->Size; i++) {
		DestroyArchive(&(O->Files[i]));
	}
	free(O->Files);
}

unsigned int GetArchiveIndex(const Output* O, const String* ArchiveName){
	for (unsigned int i = 0; i < O->Size; i++) {
		if (CompareStrings(ArchiveName, &(O->Files[i].Name))) {
			return i;
		}
	}
	printf("Error: Failure to find Archive in Output\n");
	exit(-1);
}

Position ColumnCoordinates(const Output* O, const String* S){
	String Preffix;
	ConstructStringFromPreffix(&Preffix, S);
	Position Result;
	Result.Row = GetArchiveIndex(O, &Preffix);
	String Suffix;
	ConstructStringFromSuffix(&Suffix, S);
	Result.Column = GetColumnIndex(&(O->Files[Result.Row]), &Suffix);
	DestroyString(&Preffix);
	DestroyString(&Suffix);
	return Result;
}

int Condition(const Output* O, const String* S1, const String* S2){
	Position P1;
	CopyPosition(&P1, ColumnCoordinates(O, S1));
	Position P2;
	CopyPosition(&P2, ColumnCoordinates(O, S2));
	return CompareStrings(&O->Files[P1.Row].Content.Entries[O->Files[P1.Row].Iterator][P1.Column], &O->Files[P2.Row].Content.Entries[O->Files[P2.Row].Iterator][P2.Column]);
}

int TotalCondition(const Output* O, const Input* I){
	int Result = 1;
	for (unsigned int i = 1; i < I->WhereLHS.Size; i++) {
		if (I->WhereLHS.Entries[i].Content != NULL) {
			Result &= Condition(O, &I->WhereLHS.Entries[i], &I->WhereRHS.Entries[i]);
		}
	}
	return Result;
}

void NullifyWithConstant(Output* O, const Position Coordinates, const String* Constant){
	if (Coordinates.Row >= O->Size || Coordinates.Column >= O->Files[Coordinates.Row].Content.Size.Column) {
		printf("Error: Trying to acces non existent File\n");
		exit(-1);
	}
	for (unsigned int i = 1; i < O->Files[Coordinates.Row].Content.Size.Row; i++) {
		if (!CompareStrings(Constant, &O->Files[Coordinates.Row].Content.Entries[i][Coordinates.Column])) {
			NullifyArchiveRow(&O->Files[Coordinates.Row], i);
			SetVectorEntry(&O->Files[Coordinates.Row].NullRows, i, 1);
		}
	}
}

void MakeConstantComparissons(Output* O, Input* I){
	for (unsigned int i = 1; i < I->WhereLHS.Size; i++) {
		if (IsComparingToConstant(I, i)) {
			if (StringHaveChar(&I->WhereLHS.Entries[i], '.')) {
				Position Coordinates;
				CopyPosition(&Coordinates, ColumnCoordinates(O, &I->WhereLHS.Entries[i]));
				NullifyWithConstant(O, Coordinates, &I->WhereRHS.Entries[i]);
			}
			else {
				Position Coordinates;
				CopyPosition(&Coordinates, ColumnCoordinates(O, &I->WhereRHS.Entries[i]));
				NullifyWithConstant(O, Coordinates, &I->WhereLHS.Entries[i]);
			}
			NullifyArrayEntry(&I->WhereLHS, i);
			NullifyArrayEntry(&I->WhereRHS, i);
		}
	}
}

void PrintCurrentLine(const Output* O, const Input* I){
	for (unsigned int i = 1; i < I->Select.Size; i++) {
		Position Current;
		CopyPosition(&Current, ColumnCoordinates(O, &I->Select.Entries[i]));
		PrintArchiveEntry(&O->Files[Current.Row], Point(O->Files[Current.Row].Iterator, Current.Column));
		printf("\t");
	}
	printf("\n");
}

void PrintOutput(Output* O, const Input* I){
	if (O->Files[O->Size - 1].Iterator >= O->Files[O->Size - 1].Content.Size.Row) {
		return;
	}
	else if (O->Files[O->FileNumber].NullRows.Entries[O->Files[O->FileNumber].Iterator] == 1) {
		O->Files[O->FileNumber].Iterator++;
		PrintOutput(O, I);
	}
	else if (O->Files[O->FileNumber].Iterator >= O->Files[O->FileNumber].Content.Size.Row) {
		O->Files[O->FileNumber + 1].Iterator++;
		for (unsigned int i = 0; i <= O->FileNumber; i++) {
			O->Files[i].Iterator = 1;
		}
		PrintOutput(O, I);
	}
	else if (O->FileNumber > 0) {
		O->FileNumber -= 1;
		PrintOutput(O, I);
	}
	else {
		if (TotalCondition(O, I)) {
			PrintCurrentLine(O, I);
		}
		O->Files[O->FileNumber].Iterator++;
		PrintOutput(O, I);
	}
}
