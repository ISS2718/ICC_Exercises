#ifndef ___INPUT___
#define ___INPUT___

#include<stdio.h>
#include<stdlib.h>
#include "Array.h"

typedef struct Input {
	String Raw;
	Array Processed;
	Array Select;
	Array From;
	Array WhereLHS;
	Array WhereRHS;
}Input;

void GetRawInput(Input* I);
void ProcessedFromRaw(Input* I);
void SelectFromProcessed(Input* I);
void FromFromProcessed(Input* I);
void WhereFromProcessed(Input* I);
void ConstructInput(Input* I);
void DestroyInput(Input* I);
int IsComparingToConstant(const Input* I, const unsigned int ComparissonIndex);

#endif
