#include "Matrix.h"

void ConstructMatrix(Matrix* M, const Position Dimensions) {
	M->Entries = (String**)calloc(Dimensions.Row, sizeof(String*));
	if (M->Entries == NULL) {
		printf("Error: Failure to allocate memory for Matrix\n");
		exit(-1);
	}
	for (unsigned int i = 0; i < Dimensions.Row; i++) {
		M->Entries[i] = (String*)calloc(Dimensions.Column, sizeof(String));
		if (M->Entries[i] == NULL) {
			printf("Error: Failure to allocate memory for Matrix\n");
			exit(-1);
		}
		for (unsigned int j = 0; j < Dimensions.Column; j++) {
			ConstructString(&(M->Entries[i][j]));
		}
	}
	M->Size.Row = Dimensions.Row;
	M->Size.Column = Dimensions.Column;
}

void DestroyMatrix(Matrix* M){
	for (unsigned int i = 0; i < M->Size.Row; i++) {
		for (unsigned int j = 0; j < M->Size.Column; j++) {
			DestroyString(&(M->Entries[i][j]));
		}
		free(M->Entries[i]);
	}
	free(M->Entries);
}

void SetMatrixEntry(Matrix* M, const String* S, const Position Entry){
	if (M->Entries == NULL) {
		printf("Error: Can't set entry in nonconstructed Matrix\n");
		exit(-1);
	}
	if (Entry.Row >= M->Size.Row || Entry.Column >= M->Size.Column) {
		printf("Error: Poor specification of Matrix indexes\n");
		exit(-1);
	}
	CopyString(&(M->Entries[Entry.Row][Entry.Column]), S);
}

void NullifyMatrixEntry(Matrix* M, const Position Entry){
	if (Entry.Row >= M->Size.Row || Entry.Column >= M->Size.Column) {
		printf("Error: Trying to nullify String outside Matrix bounds\n");
		exit(-1);
	}
	NullifyString(&(M->Entries[Entry.Row][Entry.Column]));
}

void NullifyMatrixRow(Matrix* M, const unsigned int Row){
	if (Row >= M->Size.Row) {
		printf("Error: Trying to nullify Strings outside Matrix bounds\n");
		exit(-1);
	}
	for (unsigned int i = 0; i < M->Size.Column; i++) {
		NullifyString(&(M->Entries[Row][i]));
	}
}

void NullifyMatrixColumn(Matrix* M, const unsigned int Column){
	if (Column >= M->Size.Column) {
		printf("Error: Trying to nullify Strings outside Matrix bounds\n");
		exit(-1);
	}
	for (unsigned int i = 0; i < M->Size.Row; i++) {
		NullifyString(&(M->Entries[i][Column]));
	}
}

void PassStringToMatrix(Matrix* M, String* Source, const Position Entry){
	if (Entry.Row >= M->Size.Row || Entry.Column >= M->Size.Column) {
		printf("Error: Trying to pass String outside Matrix bounds\n");
		exit(-1);
	}
	PassString((&M->Entries[Entry.Row][Entry.Column]), Source);
}

int CompareEntryToConstant(const Matrix* M, const String* Constant, const Position Entry){
	if (Entry.Row >= M->Size.Row || Entry.Column >= M->Size.Column) {
		printf("Error: Trying to compare String outside Matrix bounds\n");
		exit(-1);
	}
	return CompareStrings(&(M->Entries[Entry.Row][Entry.Column]), Constant);
}

int CompareEntryToColumn(const Matrix* EntryHere, const Position Entry, const Matrix* ColumnHere, unsigned int Column){
	if (Entry.Row >= EntryHere->Size.Row || Entry.Column >= EntryHere->Size.Column || Column >= ColumnHere->Size.Column) {
		printf("Error: Trying to compare Strings outside Matrix bounds\n");
		exit(-1);
	}
	for (unsigned int i = 0; i < ColumnHere->Size.Row; i++) {
		if (CompareStrings(&(EntryHere->Entries[Entry.Row][Entry.Column]), &(ColumnHere->Entries[i][Column]))) {
			return 1;
		}
	}
	return 0;
}

int CompareEntryToRow(const Matrix* EntryHere, const Position Entry, const Matrix* RowHere, unsigned int Row){
	if (Entry.Row >= EntryHere->Size.Row || Entry.Column >= EntryHere->Size.Column || Row >= RowHere->Size.Row) {
		printf("Error: Trying to compare Strings outside Matrix bounds\n");
		exit(-1);
	}
	for (unsigned int i = 0; i < RowHere->Size.Column; i++) {
		if (CompareStrings(&(EntryHere->Entries[Entry.Row][Entry.Column]), &(RowHere->Entries[Row][i]))) {
			return 1;
		}
	}
	return 0;
}

void PrintMatrix(const Matrix* M){
	for (unsigned int i = 0; i < M->Size.Row; i++) {
		for (unsigned int j = 0; j < M->Size.Column; j++) {
			PrintString(&(M->Entries[i][j]));
			printf(" | ");
		}
		printf("\n");
	}
}

void PrintMatrixEntry(const Matrix* M, const Position Entry){
	if (Entry.Row >= M->Size.Row || Entry.Column >= M->Size.Column) {
		printf("Error: Trying to print entry outside Matrix bounds\n");
		exit(-1);
	}
	PrintString(&M->Entries[Entry.Row][Entry.Column]);
}
