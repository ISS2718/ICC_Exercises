#include "String.h"

void ConstructStringOfLength(String* S, unsigned int Length) {
	S->Size = Length;
	S->Content = (char*)calloc((1 + S->Size), sizeof(char));
	if (S->Content == NULL) {
		printf("Error: Failure to allocate memory for String\n");
		exit(-1);
	}
	for (unsigned int i = 0; i <= S->Size; i++) {
		S->Content[i] = '\0';
	}
}

void ConstructString(String* S) {
	ConstructStringOfLength(S, 0);
}

void ConstructStringFromText(String* S, const char* Text) {
	unsigned int Length = 0;
	while (Text[Length] != '\0') {
		Length++;
	}
	ConstructStringOfLength(S, Length);
	for (unsigned int i = 0; i < Length; i++) {
		S->Content[i] = Text[i];
	}
}

void ConstructStringFromSubString(String* S, const String* Source, const unsigned int InitialIndex, const unsigned int FinalIndex){
	if (Source->Content == NULL) {
		printf("Error: Can't construct String from NULL pointer\n");
		exit(-1);
	}
	if (InitialIndex > FinalIndex || FinalIndex > Source->Size) {
		printf("Error: Poor specification of subString indexes\n");
		exit(-1);
	}
	S->Size = 1 + (FinalIndex - InitialIndex);
	S->Content = (char*)calloc(1 + S->Size, sizeof(char));
	if (S->Content == NULL) {
		printf("Error: Failure to allocate memory for String construction\n");
		exit(-1);
	}
	for (unsigned int i = 0; i < S->Size; i++) {
		S->Content[i] = Source->Content[InitialIndex + i];
	}
	S->Content[S->Size] = '\0';
}

void ConstructStringFromString(String* S, const String* Source){
	ConstructStringFromSubString(S, Source, 0, Source->Size - 1);
}

void ConstructStringFromPreffix(String* S, const String* Source){
	for (unsigned int i = 0; i < Source->Size; i++) {
		if (Source->Content[i] == '.') {
			ConstructStringFromSubString(S, Source, 0, i - 1);
			return;
		}
	}
	ConstructStringFromString(S, Source);
}

void ConstructStringFromSuffix(String* S, const String* Source){
	for (unsigned int i = 0; i < Source->Size; i++) {
		if (Source->Content[i] == '.') {
			ConstructStringFromSubString(S, Source, i + 1, Source->Size - 1);
			return;
		}
	}
	ConstructString(S);
}

void DestroyString(String* S) {
	free(S->Content);
}

void PushCharIntoString(String* S, const char Character){
	if (S->Content == NULL) {
		printf("Error: Trying to push character into unconstructed String\n");
		exit(-1);
	}
	S->Size += 1;
	char* Temporary = (char*)realloc(S->Content, (1 + S->Size) * sizeof(char));
	if (Temporary == NULL) {
		printf("Error: Unable to push character into String\n");
		exit(1);
	}
	S->Content = Temporary;
	S->Content[S->Size - 1] = Character;
	S->Content[S->Size] = '\0';
}

void PushTextIntoString(String* S, const char* Text){
	if (S->Content == NULL) {
		printf("Error: Trying to push text into an unconstructed String\n");
		exit(-1);
	}
	unsigned int InitialSize = S->Size;
	unsigned int TextSize = GetTextSize(Text);
	S->Size += TextSize;
	char* Temporary = (char*)realloc(S->Content, (1 + S->Size) * sizeof(char));
	if (Temporary == NULL) {
		printf("Error: Unable to push text into String\n");
		exit(1);
	}
	S->Content = Temporary;
	for (unsigned int i = 0; i <= TextSize; i++) {
		S->Content[InitialSize + i] = Text[i];
	}
	S->Content[S->Size] = '\0';
}

int CompareStrings(const String* S1, const String* S2){
	/*if (S1->Content == NULL || S2->Content == NULL) {
		printf("Error: Comparing to NULL String\n");
		exit(-1);
	}*/
	if (S1->Size != S2->Size) {
		return 0;
	}
	for (unsigned int i = 0; i <= S1->Size; i++) {
		if (S1->Content[i] != S2->Content[i]) {
			return 0;
		}
	}
	return 1;
}

int StringIsText(String* S, const char* Text){
	if (S->Content == NULL) {
		printf("Error: Comparing NULL String to text\n");
		exit(-1);
	}
	if (S->Size != GetTextSize(Text)) {
		return 0;
	}
	for (unsigned int i = 0; i <= S->Size; i++) {
		if (S->Content[i] != Text[i]){
			return 0;
		}
	}
	return 1;
}

int StringHaveChar(const String* S, const char Character){
	for (unsigned int i = 0; i <= S->Size; i++) {
		if (S->Content[i] == Character) {
			return 1;
		}
	}
	return 0;
}

void CopySubString(String* Destiny, const String* Source, const unsigned int InitialIndex, const unsigned int FinalIndex){
	DestroyString(Destiny);
	ConstructStringFromSubString(Destiny, Source, InitialIndex, FinalIndex);
}

void CopyString(String* Destiny, const String* Source){
	DestroyString(Destiny);
	ConstructStringFromString(Destiny, Source);
}

void SetStringToPreffix(String* Destiny, const String* Source){
	for (unsigned int i = 0; i < Source->Size; i++) {
		if (Source->Content[i] == '.') {
			CopySubString(Destiny, Source, 0, i - 1);
			return;
		}
	}
	CopyString(Destiny, Source);
}

void NullifyString(String* S){
	DestroyString(S);
	S->Size = 0;
	S->Content = NULL;
}

void SetStringToSuffix(String* Destiny, const String* Source){
	for (unsigned int i = 0; i < Source->Size; i++) {
		if (Source->Content[i] == '.') {
			CopySubString(Destiny, Source, i + 1, Source->Size - 1);
			return;
		}
	}
	DestroyString(Destiny);
	ConstructString(Destiny);
}

int MinStringSize(const String* S1, const String* S2){
	if (S1->Size < S2->Size) {
		return S1->Size;
	}
	return S2->Size;
}

int PreffixIsString(const String* PreffixOfThat, const String* IsThat){
	String Preffix;
	ConstructString(&Preffix);
	SetStringToPreffix(&Preffix, PreffixOfThat);
	int Result = CompareStrings(&Preffix, IsThat);
	DestroyString(&Preffix);
	return Result;
}

int SuffixIsString(const String* SuffixOfThat, const String* IsThat){
	String Suffix;
	ConstructString(&Suffix);
	SetStringToSuffix(&Suffix, SuffixOfThat);
	int Result = CompareStrings(&Suffix, IsThat);
	DestroyString(&Suffix);
	return Result;
}

void PassString(String* Destiny, String* Source){
	DestroyString(Destiny);
	Destiny->Size = Source->Size;
	Destiny->Content = Source->Content;
	Source->Content = NULL;
	Source->Size = 0;
}

void PrintString(const String* S){
	unsigned int i = 0;
	while (S->Content[i] != '\0') {
		printf("%c", S->Content[i]);
		i++;
	}
}
