#ifndef ___OTHER___
#define ___OTHER___

#include <stdio.h>
#include <stdlib.h>

typedef struct Position {
	unsigned int Row;
	unsigned int Column;
}Position;

typedef struct Vector {
	int* Entries;
	unsigned int Size;
}Vector;

void ConstructVector(Vector* V, const unsigned int size);
void DestroyVector(Vector* V);
void SetVectorEntry(Vector* V, const unsigned int Entry, const int Value);

Position Point(const unsigned int R, const unsigned int C);
void CopyPosition(Position* Destiny, const Position Source);
unsigned int GetTextSize(const char* Text);
unsigned int GetBinaryDigit(unsigned int N, unsigned int Position);

#endif