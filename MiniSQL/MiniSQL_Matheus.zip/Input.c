#include "Input.h"

void GetRawInput(Input* I){
	ConstructString(&(I->Raw));
	char Current;
	while (scanf("%c", &Current) != EOF) {
		PushCharIntoString(&(I->Raw), Current);
	}
}

void ProcessedFromRaw(Input* I){
	ConstructArrayFromText(&(I->Processed), "Processed:");
	String Current;
	ConstructString(&Current);
	unsigned int i = 0;
	while (i < I->Raw.Size) {
		if (I->Raw.Content[i] != ':' && I->Raw.Content[i] != ' ' && I->Raw.Content[i] != ',' && I->Raw.Content[i] != '=' && I->Raw.Content[i] != '"') {
			PushCharIntoString(&Current, I->Raw.Content[i]);
			i++;
		}
		else {
			if (!StringIsText(&Current, "and")) {
				PushStringIntoArray(&(I->Processed), &Current);
			}
			DestroyString(&Current);
			ConstructString(&Current);
			while (I->Raw.Content[i] == ':' || I->Raw.Content[i] == ' ' || I->Raw.Content[i] == ',' || I->Raw.Content[i] == '=' || I->Raw.Content[i] == '"') {
				i++;
			}
		}
	}
	DestroyString(&Current);
}

void SelectFromProcessed(Input* I){
	ConstructArrayFromText(&(I->Select), "Select:");
	for (unsigned int i = 0; i < I->Processed.Size; i++) {
		if (StringIsText(&(I->Processed.Entries[i]), "select")) {
			i++;
			while (!StringIsText(&(I->Processed.Entries[i]), "from") && !StringIsText(&(I->Processed.Entries[i]), "where") && i < I->Processed.Size) {
				PushStringIntoArray(&(I->Select), &(I->Processed.Entries[i]));
				i++;
			}
			return;
		}
	}
}

void FromFromProcessed(Input* I){
	ConstructArrayFromText(&(I->From), "From:");
	for (unsigned int i = 0; i < I->Processed.Size; i++) {
		if (StringIsText(&(I->Processed.Entries[i]), "from")) {
			i++;
			while (!StringIsText(&(I->Processed.Entries[i]), "where") && !StringIsText(&(I->Processed.Entries[i]), "select") && i < I->Processed.Size) {
				PushStringIntoArray(&(I->From), &(I->Processed.Entries[i]));
				i++;
			}
			return;
		}
	}
}

void WhereFromProcessed(Input* I){
	ConstructArrayFromText(&(I->WhereLHS), "WhereLHS:");
	ConstructArrayFromText(&(I->WhereRHS), "WhereRHS:");
	for (unsigned int i = 0; i < I->Processed.Size; i++) {
		if (StringIsText(&(I->Processed.Entries[i]), "where")) {
			i++;
			while (i + 1 < I->Processed.Size) {
				PushStringIntoArray(&(I->WhereLHS), &(I->Processed.Entries[i]));
				i++;
				PushStringIntoArray(&(I->WhereRHS), &(I->Processed.Entries[i]));
				i++;
			}
			return;
		}
	}
}

void ConstructInput(Input* I){
	GetRawInput(I);
	ProcessedFromRaw(I);
	SelectFromProcessed(I);
	FromFromProcessed(I);
	WhereFromProcessed(I);
}

void DestroyInput(Input* I)
{
	DestroyString(&(I->Raw));
	DestroyArray(&(I->Processed));
	DestroyArray(&(I->Select));
	DestroyArray(&(I->From));
	DestroyArray(&(I->WhereLHS));
	DestroyArray(&(I->WhereRHS));
}

int IsComparingToConstant(const Input* I, const unsigned int ComparissonIndex){
	if (ComparissonIndex >= I->WhereLHS.Size) {
		printf("Error: Trying to acces out of bounds position on Array\n");
		exit(-1);
	}
	return !(StringHaveChar(&I->WhereLHS.Entries[ComparissonIndex], '.') && StringHaveChar(&I->WhereRHS.Entries[ComparissonIndex], '.'));
}
