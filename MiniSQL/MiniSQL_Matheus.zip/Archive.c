#include "Archive.h"

void ConstructArchive(Archive* A, const String ArchiveName){
	A->Iterator = 1;
	ConstructStringFromString(&(A->Name), &ArchiveName);
	String Name;
	ConstructStringFromString(&Name, &ArchiveName);
	PushTextIntoString(&Name, ".tsv");
	FILE* File = fopen(Name.Content, "r");
	if (File == NULL) {
		printf("Error: Unable to open file to construct Archive\n");
		exit(-1);
	}
	unsigned int Tabs = 0;
	unsigned int NewLines = 0;
	char CurrentChar;
	while ((CurrentChar = getc(File)) != EOF) {
		if (CurrentChar == '\t') {
			Tabs++;
		}
		else if (CurrentChar == '\n') {
			NewLines++;
		}
	}
	Position MatrixSize = Point(NewLines, (Tabs + NewLines) / NewLines);
	ConstructMatrix(&(A->Content), MatrixSize);
	rewind(File);
	unsigned int CurrentRow = 0;
	unsigned int CurrentColumn = 0;
	String CurrentString;
	ConstructString(&CurrentString);
	while ((CurrentChar = getc(File)) != EOF) {
		if (CurrentChar == '\t') {
			PassStringToMatrix((&A->Content), &CurrentString, Point(CurrentRow, CurrentColumn));
			CurrentColumn++;
			ConstructString(&CurrentString);
		}
		else if (CurrentChar == '\n') {
			PassStringToMatrix((&A->Content), &CurrentString, Point(CurrentRow, CurrentColumn));
			CurrentRow++;
			CurrentColumn = 0;
			ConstructString(&CurrentString);
		}
		else {
			PushCharIntoString(&CurrentString, CurrentChar);
		}
	}
	ConstructVector(&A->NullRows, MatrixSize.Row);
	DestroyString(&CurrentString);
	DestroyString(&Name);
	fclose(File);
}

void DestroyArchive(Archive* A){
	DestroyMatrix((&A->Content));
	DestroyString(&(A->Name));
}

unsigned int ColumnNumber(Archive* A, const String Text){
	for (unsigned int i = 0; i < A->Content.Size.Column; i++) {
		if (CompareStrings(&(A->Content.Entries[0][i]), &Text)) {
			return i;
		}
	}
	printf("Error: Unable to find column in Archive\n");
	exit(-1);
}

void NullifyArchiveRow(Archive* A, const unsigned int Row){
	NullifyMatrixRow(&(A->Content), Row);
}

unsigned int GetColumnIndex(const Archive* A, const String* ColumnName){
	for (unsigned int i = 0; i < A->Content.Size.Column; i++) {
		if (CompareStrings(ColumnName, &(A->Content.Entries[0][i]))) {
			return i;
		}
	}
	printf("Error: Unable to find column in Archive\n");
	exit(-1);
}

void PrintArchive(const Archive* A){
	PrintString(&(A->Name));
	PrintMatrix(&(A->Content));
}

void PrintArchiveEntry(const Archive* A, const Position Entry){
	PrintMatrixEntry(&A->Content, Entry);
}
